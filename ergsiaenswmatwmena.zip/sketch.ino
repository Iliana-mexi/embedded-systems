const int pulsePin = A3;
const int ldrPin = A1;
const int tempPin = A2;

const int ledLightPin = 2;
const int ledFirePin = 3;
const int buzzerPin = 6;

// Μεταβλητά thresholds (θα υπολογιστούν στην αρχή)
int ldrThreshold=500;
float tempThreshold=40;

bool fireDetected = false;
int pulseBefore = 0;
int pulseAfter = 0;

void setup() {
  pinMode(ledLightPin, OUTPUT);
  pinMode(ledFirePin, OUTPUT);
  pinMode(buzzerPin, OUTPUT);
  Serial.begin(9600);

  calibrateSensors(); // 🔧 Καλούμε την αυτόματη βαθμονόμηση
}

void loop() {
  int ldrValue = analogRead(ldrPin);
  int tempValue = analogRead(tempPin);
  float temperature = ((float)tempValue / 1023.0) * 165.0 - 40.0;

  Serial.print("LDR: ");
  Serial.print(ldrValue);
  Serial.print("  Temp: ");
  Serial.println(temperature);

  // Ανίχνευση φωτός (για LED1)
  if (ldrValue > ldrThreshold) {
    digitalWrite(ledLightPin, HIGH);
  } else {
    digitalWrite(ledLightPin, LOW);
  }

  // Ανίχνευση πυρκαγιάς
  if (ldrValue < ldrThreshold && temperature > tempThreshold) {
  if (!fireDetected) {
    fireDetected = true;
    Serial.println("🔥 ΠΥΡΚΑΓΙΑ ΑΝΙΧΝΕΥΘΗΚΕ!");

    digitalWrite(ledFirePin, HIGH);
    tone(buzzerPin, 1000);

    pulseBefore = readPulse();
    Serial.print("❤️ Παλμοί ΠΡΙΝ: ");
    Serial.println(pulseBefore);

    delay(1000);

    pulseAfter = readPulse();
    Serial.print("❤️ Παλμοί ΜΕΤΑ: ");
    Serial.println(pulseAfter);
  }

  // Αν ήδη είχε εντοπιστεί, κρατά το σύστημα ενεργό
  digitalWrite(ledFirePin, HIGH);
  tone(buzzerPin, 1000);
} else {
  fireDetected = false;
  digitalWrite(ledFirePin, LOW);
  noTone(buzzerPin);
  Serial.println("✅ Δεν ανιχνεύθηκε πυρκαγιά.");
}
delay(1000);
}



int readPulse() {
  int signal = analogRead(pulsePin);
  return map(signal, 0, 1023, 60, 120);
}

void calibrateSensors() {
  Serial.println("🔧 Ξεκινά η βαθμονόμηση αισθητήρων για 5 δευτερόλεπτα...");
  int maxLdr = 0;
  float tempSum = 0;
  int samples = 0;

  unsigned long startTime = millis();
  while (millis() - startTime < 5000) {
    int ldr = analogRead(ldrPin);
    int tempRaw = analogRead(tempPin);
    float tempC = ((float)tempRaw / 1023.0) * 165.0 - 40.0;

    if (ldr > maxLdr) maxLdr = ldr;
    tempSum += tempC;
    samples++;

    delay(100);
  }

  ldrThreshold = maxLdr - 50;        // 50 μονάδες κάτω από μέγιστο φως
  tempThreshold = (tempSum / samples) + 5.0;  // +5°C από μέση θερμοκρασία

  Serial.print("✅ LDR Threshold: ");
  Serial.println(ldrThreshold);
  Serial.print("✅ Temp Threshold: ");
  Serial.println(tempThreshold);
}